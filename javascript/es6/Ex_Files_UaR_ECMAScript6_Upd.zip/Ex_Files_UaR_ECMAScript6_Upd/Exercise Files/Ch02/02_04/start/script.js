var nameBuilder = function(firstName="Joe", lastName="Doe") {
			console.log(firstName + " " + lastName);
		};

nameBuilder();